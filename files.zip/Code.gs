// Вставьте этот код в Extensions → Apps Script (открывается прямо из
// вашей Google Таблицы), сохраните и разверните как Web App (см. README).

var SECRET = '43a18b7e7cec362c93882475ed6d0d7e7c864ee5';
var SPREADSHEET_ID = '19jD-hGEjhxHs0lmiSOOG9vrjsAJR4Hc9HFIU6GxhhhI';
var SHEET_NAME = 'БД_Общая';

function doPost(e) {
  try {
    var body = JSON.parse(e.postData.contents);
    if (body.secret !== SECRET) {
      return jsonOutput({ ok: false, error: 'unauthorized' });
    }
    var sheet = SpreadsheetApp.openById(SPREADSHEET_ID).getSheetByName(SHEET_NAME);
    sheet.appendRow([body.date, body.amount, body.note || '', body.category, body.type]);
    return jsonOutput({ ok: true });
  } catch (err) {
    return jsonOutput({ ok: false, error: String(err) });
  }
}

function jsonOutput(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
